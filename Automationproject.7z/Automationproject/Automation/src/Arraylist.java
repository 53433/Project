import java.util.ArrayList;

public class Arraylist {

	public static void main(String[] args) {
		
		ArrayList<String> list=new ArrayList<>();
		list.add("Apple");
		list.add("Banana");
		list.add("Mango");
		System.out.println(list.size());
		System.out.println(list.get(0));
		for(String lists:list){
			System.out.println(lists);
		}
		
		

	}

}
