

public class Reversenumber {

	public static void main(String[] args) {
		
		int i=10;
		try{
			System.out.println("inside try block");
			int k=i/0;
		}catch(Exception e){
		 System.out.println("inside catch block");
		 System.out.println("divide by zero error");
			
		}
		finally{
			System.out.println("Execute this code");
		}
	}

}
