import java.util.Scanner;

public class Class {
	
	Scanner sc=new Scanner(System.in);
	int salary;
	String name;

	
	public void  getDetails(){
		System.out.println("Enter a salary");
		salary=sc.nextInt();
		System.out.println("Enter a name");
		name=sc.next();
	}
	 public void DisplayDetails(){
		 System.out.println("The salary is " +salary+ " and the name is " +name);
	 }

	public static void main(String[] args) {
		Class c=new Class();
		c.getDetails();
		c.DisplayDetails();
		
	}
	
		
		
		
			
			
		

	}


