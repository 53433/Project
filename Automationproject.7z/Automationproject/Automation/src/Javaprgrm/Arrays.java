package Javaprgrm;

public class Arrays {

	public static void main(String[] args) {
		
		int[] myList={1,2,3,4,5,6};
		for(int i=0;i<myList.length;i++)
		{
			System.out.println(myList[i]+"");
		}
	}

}
