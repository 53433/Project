package Javaprgrm;

import java.util.ArrayList;

public class Arraylist {

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static void main(String[] args) {


		//Declaration
		 ArrayList<String> list=new ArrayList<String>();

		 
		 list.add("John");
		 list.add("David");
		 list.add("Scott");
		 list.add("Smith");

		 System.out.println(list.size()); 

		
		 for(String s:list)
		 {
		  System.out.println(s);
		 }

		}

		}
