package Javaprgrm;

public class Date {

	public static void main(String[] args) {
		
		// Instantiate a Date object
		Date date=newDate();
		// display time and date using toString()
		System.out.println(date.toString());
		}

	private static Date newDate() {
		// TODO Auto-generated method stub
		return null;
	} }