package Javaprgrm;

import java.io.IOException;

public class Oddevennumber {

	public static void main(String[] args) throws IOException {

		Runtime rs=Runtime.getRuntime();
		rs.exec("Snippingtool");
		
	}
		 

}



			

