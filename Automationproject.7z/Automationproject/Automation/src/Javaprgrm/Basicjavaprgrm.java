package Javaprgrm;

public class Basicjavaprgrm {

	public static void main(String[] args) {
		
		System.out.println("Hello world");
	}

}
