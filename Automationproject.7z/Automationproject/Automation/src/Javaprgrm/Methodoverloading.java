package Javaprgrm;

public class Methodoverloading {
	
	
	public static void main(String[] args) {
		
		String x="100";
		System.out.println(x+20);
		
		int i=
	}

}
