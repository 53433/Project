package Javaprgrm;

public class Loops {

	@SuppressWarnings("unused")
	public static void main(String[] args) {
	
	  	
	  for(int x=0;x<10;x=x+1){
	  System.out.println("Value of x is :" +x);
	  continue;
	}
	}
}


		     
	     
		




