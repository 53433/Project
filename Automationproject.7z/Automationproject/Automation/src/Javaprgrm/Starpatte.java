package Javaprgrm;

import java.util.HashSet;
import java.util.Set;

public class Starpatte {

	public static void main(String[] args) {
		
	String infra[]={"Amazon","GCP","Azure","Amazon","Ai Baba","Azure","GCP"};
	System.out.println("********Hashset******");
	Set<String> data=new HashSet<String>();
	for(int i=0;i<infra.length;i++){
		for(int j=i+1;j<infra.length;j++){
			if(infra[i].equals(infra[j])){
				System.out.println(infra[i]);
			}
		}
	}
	}
	
				
			
		}





         
	
	


