package Javaprgrm;

import java.util.ArrayList;

public class Secondexamplearraylist {

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static void main(String[] args) {
		
		 //Declaration
		 ArrayList list=new ArrayList(); 

		 //Adding values to array list
		 list.add("welcome");
		 list.add(100);
		 list.add(10.5);
		 list.add('C');
		 list.add(true);
		 
		 System.out.println(list.size());
		 
		 System.out.println(list.get(2));
		 
		 System.out.println("Before inserting:" +list);
		 
		 list.add(1,"Selenium");
		 System.out.println("After insertion:" +list);
		 
		 list.add(2,"Selenium");
		 System.out.println("After insertion:" +list);
		 
		 list.remove(3);
		 System.out.println("Afer remove:" +list);
		 
		 for(Object i:list)
		 {
			 System.out.println(i);
		 }
		 
		 
		
		
		

	}

}
