
public class Removejunkchar {

	public static void main(String[] args) {
		
		String str="Welcome to india";
		s=str.split(" ");
		System.out.println(s);
	}

}
