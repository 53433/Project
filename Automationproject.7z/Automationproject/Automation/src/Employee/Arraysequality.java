package Employee;

public class Arraysequality {

	public static void main(String[] args) {
		
		String s="ინდოეთი selenium ინდოეთი testing 34567";
		s=s.replaceAll("[^a-zA-Z0-9]", " ");
	}

}
