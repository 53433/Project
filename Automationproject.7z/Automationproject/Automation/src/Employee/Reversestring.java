package Employee;

import java.util.Scanner;

public class Reversestring {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a string");
		String s=sc.nextLine();
		char[]newString=new char[s.length()];
		int j=0;
		for(int i=s.length() -1;i>=0;i--){
			newString[j]=s.charAt(i);
			j++;
			
		}
		System.out.println("Reverse of given string is :");
		for(char rev:newString){
			System.out.println(rev);
		}
		
		sc.close();
			
		}
		

		 



	}

