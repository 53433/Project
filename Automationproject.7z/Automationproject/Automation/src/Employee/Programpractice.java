package Employee;

public class Programpractice {

	public static void main(String[] args) {
          
		String s="Welcome";
		String rev="";
		int len=s.length();
		for(int i=len-1;i>=0;i--){
			rev=rev+s.charAt(i);
	
}
		System.out.print("Reversed string is " + rev);
	}
}




