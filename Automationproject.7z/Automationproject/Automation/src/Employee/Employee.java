package Employee;

public class Employee {

	public static void main(String[] args) {
		
		String s="AHCECLWLXO";
		String[] split=s.split("");
		for(int i=1;i<split.length;i=i+2)
		{
			System.out.println(split[i]);
		}
		System.out.println("\n................");

	}

}
