package Employee;

import java.util.Scanner;

public class Javaprgrm {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		
		int[] arr=new int[5];
		
		for(int i=0;i<3;i++)
		{
		   System.out.println("Enter a number");
		   arr[i]=sc.nextInt();
		}
        
		for(int i=0;i<3;i++)
		{
			System.out.println(arr[i]);
		}
		
}

}
