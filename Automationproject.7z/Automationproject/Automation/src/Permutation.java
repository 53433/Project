
public class Permutation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
