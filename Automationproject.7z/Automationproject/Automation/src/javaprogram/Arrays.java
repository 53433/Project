package javaprogram;

public class Arrays {

	public static void main(String[] args) {
		
		int a[]=new int[5];
		a[0]=1;
		a[1]=5;
		a[2]=6;
		System.out.println(a[0]);

	}

}
