
class a
{
int i;
}
class test
{
public static void main(String args[])
a A=new a();
System.out.println(A.i);
}