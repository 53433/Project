
public class Swapnumbers {

	public static void main(String[] args) {
		
		int a=10;int b=20;
		System.out.println("Before swapping numbers are .."+a+"  "+b);
		b=a+b-(a=b);
		System.out.println("After  swapping numbers are .."+a+"  "+b);

	}

}
