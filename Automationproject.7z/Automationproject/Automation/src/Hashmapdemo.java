import java.util.HashMap;

public class Hashmapdemo {

	public static void main(String[] args) {
		
		HashMap m=new HashMap();
		m.put(1,"a");
		m.put(2, "a");
		m.put(1, "b");
		System.out.println(m);
		
				
	}

}
