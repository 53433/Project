
public class Removejunkcharacters {

	public static void main(String[] args) {
		
		
		String s="ინდოეთი  testing 123456";
		String s1="ინდოეთი selenium ინდოეთი testing 34567";
		
		s=s.replaceAll("[^a-zA-Z0-9]", " ");
		System.out.println(s);
	}

}
