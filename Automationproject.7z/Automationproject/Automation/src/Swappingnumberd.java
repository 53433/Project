
public class Swappingnumberd {

	public static void main(String[] args) {
		
		 int a=10,b=20;
		 System.out.println("Before Swapping values :"+a+"   "+b);
		 int t=a;
		 a=b;
		 b=t;
		 System.out.println("after  Swapping values :"+a+"   "+b);
	}

}
