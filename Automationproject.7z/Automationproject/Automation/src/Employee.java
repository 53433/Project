import java.util.Scanner;

public class Employee {
	Scanner sc=new Scanner(System.in);
	private String name;
	private int salary;
	
	public void getDetails(){
		System.out.println("Enter a name");
		name=sc.next();
		System.out.println("Enter a salary");
		salary=sc.nextInt();
	}
		
	public void Displaydetails(){
		System.out.println("the name is "+name+" and the salary is "+salary);
	}
		
		
	public static void main(String[] args) {
		Employee e =new Employee();
		e.getDetails();
		e.Displaydetails();
		
		

}
}

