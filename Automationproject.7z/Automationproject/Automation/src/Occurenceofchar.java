
public class Occurenceofchar {

	public static void main(String[] args) {
		
		String s = "Java is java again java again";
		int charCount = 0;
		for(char ch: s.toCharArray()){
		if(ch == 'a'){
		charCount++;
		}
		}
	}
}

		
		
		
		
	


