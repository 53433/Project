
public class Removestring {

	public static void main(String[] args) {
		
		//Remove a string by using inbuilt function
		
		String s="Welcome";
		//1st Method
		//StringBuilder sb=new StringBuilder(s);
		//System.out.println(sb.reverse());
	
		//2nd Method
		//StringBuffer sb=new StringBuffer(s);
		//System.out.println(sb.reverse());
		
		//3rdMethod
		//char[] strChar = s.toCharArray();
		//for (int i = (s.length() - 1); i >= 0; i--) {
		//System.out.print(strChar[i]);
		
		//4thmethod
		
		//for(int i=(s.length()-1);i>=0;i--)
		//{
		//	System.out.print(s.charAt(i));
			
		
			
		}

	}

}
