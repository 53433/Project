package Javaprgrmpractice;

public class Countcharactersoccurences {

	public static void main(String[] args) {
		
		String s="java Programming java oops";
		int totalcount=s.length();
		int totalcountAfterremove=s.replace("a", "").length();
		int count=totalcount-totalcountAfterremove;
		System.out.println("Count is:"+count );
	}

}
