package Javaprgrmpractice;

public class Removewhitespaceinstring {

	public static void main(String[] args) {
		
		String s="Java    Programming   question";
		System.out.println("Before removing whitespaces" +s);
		s=s.replaceAll("\\s", "");
		System.out.println("After removing white spaces:"+s);
	}

}
