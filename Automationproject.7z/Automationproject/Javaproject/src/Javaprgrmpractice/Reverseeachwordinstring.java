package Javaprgrmpractice;

public class Reverseeachwordinstring {

	public static void main(String[] args) {
		
		/*String s="Welcome to java and selenium";
		String[] words=s.split(" ");
		String reversedStrings="";
		for(String w:words){
			String reversedwords="";
			for(int i=w.length()-1;i>=0;i--){
				reversedwords=reversedwords+w.charAt(i);
			}
			reversedStrings=reversedStrings+reversedwords+" ";
		}
		System.out.println(reversedStrings);*/

		String s="Welcome to java";
		String []words=s.split("\\s");
		String reversedwords="";
		for(String w:words){
			StringBuilder sb=new StringBuilder(w);
			sb.reverse();
		
		reversedwords=reversedwords+sb.toString()+" ";
	}
       System.out.println(reversedwords);
}
}

