package Javaprgrmpractice;

public class Reversestring {

	public static void main(String[] args) {
		
		//String s="Welcome to india";
		// 1st method inbuild method
		
		//StringBuilder sb=new StringBuilder(s);
		//System.out.println(sb.reverse());
		
		//2nd method 
		//using string concatenation method
		/*String s="ABCD";
		String rev="";
		
		int len =s.length();
		for(int i=len-1;i>=0;i--){
			rev=rev+s.charAt(i);
		}
		System.out.println("The reverse string is :" +rev);*/
		
		//by using char At array
	/*	String s="ABCD";
		String rev="";
		char a[]=s.toCharArray();
		int len=a.length;
		for(int i=len-1;i>=0;i--){
			rev=rev+a[i];
		}
		System.out.println("The reversed string is :" +rev);*/
		
		//String buffer method
		String s="Welcome to java and selenium";
		StringBuffer sb=new StringBuffer(s);
		System.out.println(sb.reverse());
		

	}

}
