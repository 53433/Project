package Javaprgrmpractice;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;

public class Comparelist {

	public static void main(String[] args) {
		
		HashMap<String, String>Map1=new HashMap<String,String>();
		Map1.put("India", "NewDelhi");
		Map1.put("UK", "NewDelhi");
		Map1.put("India", "London");
		
		System.out.println(Map1);
		
	}

}
