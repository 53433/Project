package Javaprgrmpractice;

import java.util.Scanner;

public class Palindromestring {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a string");
		String str=sc.next();
		String orig_str=str;
		String rev="";
		int len=str.length();
		for(int i=len-1;i>=0;i--){
			rev=rev+str.charAt(i);
		}
		if(orig_str.equals(rev)){
			System.out.println("String is palindrome");
		}
		else
			System.out.println("String is not palindrome");
		

	}

}
