package Javaprgrmpractice;

public class Removejunkcharactersstring {

	public static void main(String[] args) {
		
		String s="இந்தியாவிற்கு வரவேற்கிறோம் latin string 12345";
		s=s.replaceAll("[^a-zA-Z0-9]", "");
		System.out.println(s);
	}

}
