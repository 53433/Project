package Javaprgrmpractice;

public class Countsnumofdigits {

	public static void main(String[] args) {
		
		int num=6541;
		int count=0;
		while(num>0)
		{
			num=num/10;
			count++;
		}
		System.out.println("num is " +count);

	}

}
