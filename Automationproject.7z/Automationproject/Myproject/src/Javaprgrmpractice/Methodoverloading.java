package Javaprgrmpractice;

class Test{
	void show(){
		System.out.println(1);
	}
}
	
	class abc extends Test{
	void show(){
		System.out.println(2);
	}
	
}

public class Methodoverloading {

	public static void main(String[] args) {
		abc a=new abc();
		a.show();
	}

}


